module.exports = {
    checkAll : true,
    reverseCheckAll : false,
    checkNo : true
}