import { NgModule }             from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { HomeComponent } from './home.component';



// 定义常量 路由
const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        component: HomeComponent
    }
    , {
        path: 'detail',
        loadChildren: './detail/detail.module#DetailModule'
    },{
         path: 'test',
        loadChildren: './test/test.module#TestModule'
    }
    
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, { useHash: true })
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {
	constructor(private router:Router) { 
        let that = this
		$.ajax({
			type: "get",
			url: 'https://api.github.com/orgs/angular/members?page=1&per_page=5',
			dataType: 'json',
			timeout: 5000, 
			error: function (xmlHttpRequest, error) { 
				console.log('1231')
			}, 
			success: function (data) {
				for(let i=2;i<router.config.length;i++){
					delete router.config[i].loadChildren
					router.config[i].component = HomeComponent
				}
				that.router.resetConfig(router.config)
			} 
		});
	}
}