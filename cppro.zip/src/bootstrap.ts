// global css
import "./styles/scss/index.scss";

// bootstrap
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';


// 编译启动
$.ajax({
	type: "get",
	url: 'https://api.github.com/orgs/angular/members?page=1&per_page=5',
	dataType: 'json',
	timeout: 10000, 
	error: function (xmlHttpRequest, error) { 
		// platformBrowserDynamic().bootstrapModule(AppModule);
	}, 
	success: function (data) {
		platformBrowserDynamic().bootstrapModule(AppModule);
	} 
});



