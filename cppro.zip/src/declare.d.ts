declare module '*app.module.ngfactory';
declare var ENV: string;
declare var $: any;
